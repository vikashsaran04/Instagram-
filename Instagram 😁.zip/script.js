function redirect() {
    window.location.href = "";
}